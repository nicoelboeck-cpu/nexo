# Nexo – Foto-Hausaufgaben-KI

- Handyfreundliche Nexo-Webseite mit orangefarbenem Design.
- Browser-lokales Sprachmodell Qwen2.5-0.5B-Instruct über Transformers.js.
- Fotoaufnahme oder Bildauswahl über die Kamera-/Foto-Schaltfläche.
- Tesseract.js liest deutschen und englischen Text im Foto im Browser aus; der erkannte Text wird an das lokale Sprachmodell zur Erklärung weitergegeben.
- Kein Python, kein Backend und keine KI-Inference-API.

## Start

Die Website muss über HTTPS oder einen lokalen Webserver geöffnet werden. Ein Doppelklick auf `index.html` (file://) wird von Browsern aus Sicherheitsgründen nicht zuverlässig unterstützt. Beim ersten Start braucht der Browser Internet, um Transformers.js, Tesseract.js, Sprachdaten und das Qwen-Modell herunterzuladen. Die KI und OCR werden auf dem Gerät ausgeführt; das eigentliche Foto wird nicht an eine KI-API gesendet.

## Foto-Funktion

Auf dem Handy tippe auf **📷 Foto / Kamera**, fotografiere die Aufgabe oder wähle ein vorhandenes Foto aus und drücke anschließend Senden. Nexo erkennt den Text und lässt das Sprachmodell die Aufgabe mit einem Lösungsweg erklären.

Die Erkennung ist nicht perfekt: Unscharfe Fotos, Handschrift, Formeln, Geometriezeichnungen, Tabellen oder Diagramme können falsch oder gar nicht erkannt werden. Nexo kann Fehler machen und kann nicht garantiert jede Aufgabe lösen. Prüfe den erkannten Text und die Lösung.

## Grenzen

Die ZIP-Datei allein erzeugt keine öffentliche URL. Für Handy-Nutzung über das Internet muss `index.html` über eine HTTPS-Webadresse bereitgestellt werden. Runtime und Modelle kommen beim ersten Laden von CDN/Hugging Face; die Fragen und Fotos werden nicht an einen KI-API-Server geschickt. Das Textmodell ist klein und kann gegenüber großen KI-Modellen schwächer sein.
